package com.lostandfound;

import com.lostandfound.db.DatabaseConnection;
import com.lostandfound.db.DatabaseInitializer;
import com.lostandfound.db.DatabaseSeeder;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        DatabaseConnection.getConnection();
        DatabaseInitializer.initialize();
        DatabaseSeeder.seed();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle("Campus Lost & Found");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}